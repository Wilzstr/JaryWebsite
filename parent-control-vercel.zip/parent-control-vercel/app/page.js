export default function Home() {
  const card = {
    background:"#111827", border:"1px solid #243042", borderRadius:20, padding:20
  };
  const btn = {
    width:"100%", padding:"12px 14px", borderRadius:12, border:"none",
    background:"#2563eb", color:"white", fontWeight:600, cursor:"pointer"
  };

  async function send(command){
    await fetch("/api/command",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({command})
    });
    alert("Perintah: "+command);
  }

  return (
    <main style={{fontFamily:"Arial, sans-serif", background:"#0b1220", minHeight:"100vh", color:"#e5eefc"}}>
      <div style={{display:"flex"}}>
        <aside style={{width:230, padding:24, borderRight:"1px solid #1f2a3d", minHeight:"100vh"}}>
          <h2 style={{marginTop:0}}>Parent Control</h2>
          <div style={{display:"grid", gap:10}}>
            <div style={{padding:12, background:"#111827", borderRadius:12}}>Dashboard</div>
            <div style={{padding:12}}>Perangkat</div>
            <div style={{padding:12}}>Audio</div>
            <div style={{padding:12}}>Lock screen</div>
            <div style={{padding:12}}>Pengaturan</div>
          </div>
        </aside>

        <section style={{flex:1, padding:28}}>
          <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
            <div>
              <h1 style={{margin:"0 0 6px"}}>Dashboard</h1>
              <div style={{color:"#94a3b8"}}>Kontrol perangkat anak secara real-time</div>
            </div>
            <input placeholder="Cari perangkat..." style={{padding:10, borderRadius:12, border:"1px solid #243042", background:"#111827", color:"#fff"}} />
          </div>

          <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:18, marginTop:24}}>
            <div style={card}>
              <div style={{fontSize:30}}>🔦</div>
              <h3>Matikan senter</h3>
              <p style={{color:"#94a3b8"}}>Nonaktifkan senter perangkat yang dipilih.</p>
              <button style={btn} onClick={()=>send("flash_off")}>Matikan senter</button>
            </div>

            <div style={card}>
              <div style={{fontSize:30}}>🔒</div>
              <h3>Lock screen</h3>
              <p style={{color:"#94a3b8"}}>Kunci layar dengan durasi dan pesan.</p>
              <button style={{...btn, background:"#ef4444"}} onClick={()=>send("lock_screen")}>Kunci layar</button>
            </div>

            <div style={card}>
              <div style={{fontSize:30}}>🎵</div>
              <h3>Putar musik</h3>
              <p style={{color:"#94a3b8"}}>Putar MP3 atau link Catbox.</p>
              <button style={{...btn, background:"#16a34a"}} onClick={()=>send("play_audio")}>Putar audio</button>
            </div>

            <div style={card}>
              <div style={{fontSize:30}}>📱</div>
              <h3>Perangkat aktif</h3>
              <p style={{color:"#94a3b8"}}>2 online • 1 offline</p>
              <button style={btn}>Lihat perangkat</button>
            </div>
          </div>

          <h2 style={{marginTop:34}}>Daftar perangkat anak</h2>
          <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))", gap:16}}>
            {[
              {name:"Andi - Samsung A15", battery:"82%", status:"Online"},
              {name:"Sinta - Redmi Note", battery:"64%", status:"Online"},
              {name:"Budi - Vivo Y28", battery:"39%", status:"Offline"}
            ].map((d,i)=>(
              <div key={i} style={card}>
                <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                  <div>
                    <div style={{fontWeight:700}}>{d.name}</div>
                    <div style={{color:"#94a3b8", fontSize:13}}>Baterai: {d.battery}</div>
                  </div>
                  <span style={{fontSize:12, padding:"6px 10px", borderRadius:999, background:d.status==="Online"?"#123522":"#3b1d1d", color:d.status==="Online"?"#86efac":"#fca5a5"}}>{d.status}</span>
                </div>

                <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginTop:16}}>
                  <button style={btn} onClick={()=>send("flash_off")}>Senter</button>
                  <button style={{...btn, background:"#ef4444"}} onClick={()=>send("lock_screen")}>Lock</button>
                  <button style={{...btn, background:"#16a34a"}} onClick={()=>send("play_audio")}>Putar MP3</button>
                  <button style={btn}>Pengaturan</button>
                </div>
              </div>
            ))}
          </div>

          <h2 style={{marginTop:34}}>Pengaturan audio</h2>
          <div style={card}>
            <label>Link MP3 / Catbox</label>
            <input placeholder="https://files.catbox.moe/lagu.mp3" style={{width:"100%", marginTop:8, padding:12, borderRadius:12, border:"1px solid #243042", background:"#0f172a", color:"#fff"}} />
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginTop:12}}>
              <input placeholder="Volume 80%" style={{padding:12, borderRadius:12, border:"1px solid #243042", background:"#0f172a", color:"#fff"}} />
              <input placeholder="Mode loop" style={{padding:12, borderRadius:12, border:"1px solid #243042", background:"#0f172a", color:"#fff"}} />
            </div>
            <button style={{...btn, background:"#16a34a", marginTop:14}} onClick={()=>send("play_audio")}>Simpan & Putar</button>
          </div>

          <h2 style={{marginTop:34}}>Pengaturan lock screen</h2>
          <div style={card}>
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:12}}>
              <input placeholder="Durasi 15 menit" style={{padding:12, borderRadius:12, border:"1px solid #243042", background:"#0f172a", color:"#fff"}} />
              <input placeholder="Pesan: Waktu belajar" style={{padding:12, borderRadius:12, border:"1px solid #243042", background:"#0f172a", color:"#fff"}} />
            </div>
            <button style={{...btn, background:"#ef4444", marginTop:14}} onClick={()=>send("lock_screen")}>Terapkan</button>
          </div>
        </section>
      </div>
    </main>
  );
}
