export async function POST(req){
  const body = await req.json();
  return Response.json({
    ok:true,
    received:body.command,
    note:"Hubungkan endpoint ini ke Firebase Cloud Messaging (FCM) agar perintah dikirim ke perangkat anak."
  });
}
