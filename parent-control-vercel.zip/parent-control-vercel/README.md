Parent Control Dashboard (Next.js)

Deploy ke Vercel:
1. Upload folder ini ke GitHub.
2. Import repository di Vercel.
3. Deploy.

Catatan:
- Dashboard ini adalah UI modern siap Vercel.
- Endpoint /api/command adalah placeholder.
- Untuk mengontrol perangkat Android (senter, lock screen, putar audio), perangkat anak tetap memerlukan aplikasi receiver dengan izin yang sesuai dan FCM.
